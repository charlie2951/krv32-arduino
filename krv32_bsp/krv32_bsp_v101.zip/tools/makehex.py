#!/usr/bin/env python3
from sys import argv

if len(argv) < 3:
    print("Usage: ./makehex.py <input_bin> <output_hex>")
    exit(1)

binfile = argv[1]
outfile = argv[2] # New: output file path

with open(binfile, "rb") as f:
    bindata = f.read()

while len(bindata) % 4 != 0:
    bindata += b'\x00'

# Open the file for writing
with open(outfile, "w") as out:
    data_word_count = len(bindata) // 4
    for i in range(data_word_count):
        w = bindata[4*i : 4*i+4]
        line = "%02x%02x%02x%02x\n" % (w[3], w[2], w[1], w[0])
        out.write(line)
    
    out.write("ABCDEF99\n")
    out.write("FFFFFFFF\n")

print(f"Hex file successfully saved to: {outfile}")