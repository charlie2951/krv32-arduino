#ifndef PRINTF_H
#define PRINTF_H

#include <stdarg.h>
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Custom printf for bare-metal UART.
 * Supports: %s (string), %d (decimal), %x (hex), %b (binary), %% (percent)
 */
void my_printf(const char *format, ...);

/**
 * @brief Hardware-specific character output. 
 * MUST be implemented in app.c or a separate UART driver.
 */
void UART_PutChar(char c);

#ifdef __cplusplus
}
#endif

#endif // PRINTF_H