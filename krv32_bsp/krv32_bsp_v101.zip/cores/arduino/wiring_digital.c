#include "Arduino.h"

#define GPIO_BASE        0x10000000
#define GPIO_REG_DATA     ((volatile uint32_t*)(GPIO_BASE + 0x00))
#define GPIO_REG_DIR    ((volatile uint32_t*)(GPIO_BASE + 0x04))

void pinMode(uint8_t pin, uint8_t mode) {
    // Safety check against the new 16-pin limit
    if (pin >= NUM_DIGITAL_PINS) return;

    uint8_t bit = digital_pin_to_gpio[pin];
    
    if (mode == OUTPUT) {
        *GPIO_REG_DIR |= (1 << bit);
    } else {
        *GPIO_REG_DIR &= ~(1 << bit);
    }
}

void digitalWrite(uint8_t pin, uint8_t val) {
    if (pin >= NUM_DIGITAL_PINS) return;

    uint8_t bit = digital_pin_to_gpio[pin];

    if (val == HIGH) {
        *GPIO_REG_DATA |= (1 << bit);
    } else {
        *GPIO_REG_DATA &= ~(1 << bit);
    }
}

int digitalRead(uint8_t pin) {
    if (pin >= NUM_DIGITAL_PINS) return 0;

    uint8_t bit = digital_pin_to_gpio[pin];
    
    return ((*GPIO_REG_DATA & (1 << bit)) != 0) ? HIGH : LOW;
}