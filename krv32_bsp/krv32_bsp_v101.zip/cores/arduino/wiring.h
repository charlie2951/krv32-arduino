#ifndef WIRING_H
#define WIRING_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Pauses the program for the amount of time (in milliseconds) 
 * specified as parameter.
 */
void delay(unsigned long ms);

/**
 * @brief Pauses the program for the amount of time (in microseconds) 
 * specified as parameter.
 */
void delayMicroseconds(unsigned int us);

/**
 * @brief Returns the number of milliseconds passed since the program started.
 * Currently returns 0 in your implementation.
 */
unsigned long millis(void);

/**
 * @brief Returns the number of microseconds passed since the program started.
 * Currently returns 0 in your implementation.
 */
unsigned long micros(void);

#ifdef __cplusplus
}
#endif

#endif /* WIRING_H */