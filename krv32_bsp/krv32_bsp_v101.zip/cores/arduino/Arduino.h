#ifndef Arduino_h
#define Arduino_h

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "pins_arduino.h"
#include "wiring.h"
#include "HardwareSerial.h"

#ifdef __cplusplus
extern "C" {
#endif

// Standard Arduino Constants
#define HIGH 0x1
#define LOW  0x0

#define INPUT        0x0
#define OUTPUT       0x1
#define INPUT_PULLUP 0x2

#define PI 3.1415926535897932384626433832795
#define HALF_PI 1.5707963267948966192313216916398

// Basic GPIO API Prototypes
void pinMode(uint8_t pin, uint8_t mode);
void digitalWrite(uint8_t pin, uint8_t val);
int digitalRead(uint8_t pin);

// Timing Prototypes
void delay(unsigned long ms);
void delayMicroseconds(unsigned int us);
unsigned long millis(void);
unsigned long micros(void);

// Sketch entry points
void setup(void);
void loop(void);

#ifdef __cplusplus
} // extern "C"
#endif

#endif