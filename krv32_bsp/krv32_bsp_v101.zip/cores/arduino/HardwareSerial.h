#ifndef HardwareSerial_h
#define HardwareSerial_h

#include "uart.h"
#include "printf.h"

#ifdef __cplusplus

class HardwareSerial {
public:
    void begin(unsigned long baud) {
        uart_init(UART1);
    }

    // --- The Print Wrapper ---
    // %s for strings
    void print(const char *str) {
        ::my_printf("%s", str);
    }

    // %d for integers
    void print(int val) {
        ::my_printf("%d", val);
    }

    // %u for unsigned
    void print(unsigned int val) {
        ::my_printf("%u", val);
    }

    // %x for hex
    void print(int val, int format) {
        if(format == 16) ::my_printf("%x", val);
        else ::my_printf("%d", val);
    }

    // --- The Println Wrapper ---
    void println(const char *str) {
        ::my_printf("%s\r\n", str);
    }

    void println(int val) {
        ::my_printf("%d\r\n", val);
    }

    void println() {
        ::my_printf("\r\n");
    }

    // Standard printf directly on the Serial object
    void my_printf(const char *format, ...) {
        va_list args;
        va_start(args, format);
        // Note: You may need a vprintf version in printf.c 
        // to pass the va_list directly.
        va_end(args);
    }
};

extern HardwareSerial Serial;
#endif
#endif