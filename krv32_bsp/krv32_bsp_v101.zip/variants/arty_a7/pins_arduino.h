#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <stdint.h>

// Now defining 16 digital pins (0 through 15)
#define NUM_DIGITAL_PINS          16
#define NUM_ANALOG_INPUTS         0

// Mapping Arduino Pin 0-15 to Hardware GPIO 0-15
// If your hardware uses a 1:1 mapping, this array is straightforward
static const uint8_t digital_pin_to_gpio[] = {
    0, 1, 2, 3, 4, 5, 6, 7, 
    8, 9, 10, 11, 12, 13, 14, 15
};

#endif